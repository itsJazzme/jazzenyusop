<?php
	session_start();

	if(isset($_SESSION['username'])){
		header("Location: welcome.php");
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login - Vistora</title>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
	<style>
		* {
			box-sizing: border-box;
		}

		body {
			margin: 0;
			font-family: 'Inter', sans-serif;
			background: url('https://i.pinimg.com/736x/59/f3/bc/59f3bc12e6ac900d479e3239963e04bd.jpg') no-repeat center center/cover;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
			position: relative;
			color: white;
		}

		body::after {
			content: '';
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background: rgba(0, 0, 0, 0.5);
			z-index: 1;
		}

		.login-box {
			position: relative;
			z-index: 2;
			background: rgba(255, 255, 255, 0.95);
			padding: 2.5rem;
			border-radius: 12px;
			box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
			width: 100%;
			max-width: 400px;
			color: #333;
			text-align: center;
		}

		.login-box h2 {
			margin-bottom: 2rem;
			color: #46a6f4;
			font-size: 2rem;
		}

		.user-box {
			text-align: left;
			margin-bottom: 1.5rem;
		}

		.user-box label {
			display: block;
			margin-bottom: 0.5rem;
			font-weight: 600;
		}

		.user-box input {
			width: 100%;
			padding: 0.75rem;
			border: 2px solid #46a6f4;
			border-radius: 5px;
			outline: none;
			font-size: 1rem;
			color: #333;
		}

		input[type="submit"] {
			background-color: #46a6f4;
			color: white;
			padding: 0.75rem 1.5rem;
			border: none;
			border-radius: 5px;
			cursor: pointer;
			font-weight: 600;
			font-size: 1rem;
			width: 100%;
			transition: background-color 0.3s ease;
		}

		input[type="submit"]:hover {
			background-color: #3996e3;
		}

		.extra-links {
			margin-top: 1rem;
			font-size: 0.95rem;
		}

		.extra-links a {
			color: #46a6f4;
			text-decoration: none;
			margin: 0 0.5rem;
			font-weight: 500;
		}

		.extra-links a:hover {
			text-decoration: underline;
		}

		.back-home {
			position: absolute;
			top: 20px;
			left: 20px;
			z-index: 3;
		}

		.back-home a {
			color: white;
			text-decoration: none;
			font-weight: 600;
			padding: 0.4rem 1rem;
			border-radius: 6px;
			transition: background-color 0.3s ease;
			display: inline-block;
		}

		.back-home a:hover {
			background-color: rgba(57, 150, 227, 0.95);
		}

		.logo {
			position: absolute;
			top: 20px;
			right: 20px;
			color: white;
			font-size: 1.5rem;
			font-weight: 600;
			padding: 0.4rem 1rem;
			border-radius: 6px;
			z-index: 3;
			text-decoration: none;
		}

		.logo:hover {
			background-color: rgba(57, 150, 227, 0.95);
		}

		@media (max-width: 500px) {
			.login-box {
				padding: 2rem 1.5rem;
			}
			.back-home a, .logo {
				padding: 0.3rem 0.8rem;
				font-size: 0.9rem;
			}
		}
	</style>
</head>
<body>

	<div class="back-home">
		<a href="index.html">&larr; Back to Homepage</a>
	</div>

	<a href="index.html" class="logo">Vistora</a>

	<div class="login-box">
		<h2>Login</h2>
		<form action="checkuser.php" method="POST">
			<div class="user-box">
				<label for="username">Username</label>
				<input type="text" name="username" required>
			</div>
			<div class="user-box">
				<label for="password">Password</label>
				<input type="password" name="password" required>
			</div>
			<input type="submit" value="LOGIN" />
		</form>

		<div class="extra-links">
			<a href="register.php">Sign Up</a> |
			<a href="forgot-password.php">Forgot Password?</a>
		</div>
	</div>
</body>
</html>
